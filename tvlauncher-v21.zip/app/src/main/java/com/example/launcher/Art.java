package com.example.launcher;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

import java.util.Random;

/**
 * Встроенные обои и фоны. Всё рисуется кодом один раз в маленькую картинку,
 * дальше на экран выводится готовая картинка: это почти не грузит слабую приставку.
 */
final class Art {

    static final String[] NAMES = {
            "Горы", "Северное сияние", "Синтвейв", "Звёздное небо",
            "Лоу-поли", "Боке", "Дюны", "Лунная ночь"
    };

    private Art() { }

    /** style: 0 волны, 1 градиент, 3 встроенные обои. */
    static Bitmap make(int style, int preset, int variant, int[] bg, int[] wave,
                       float mul, int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565);
        Canvas c = new Canvas(b);
        if (style == 3) {
            Random r = new Random(1000L * (preset + 1) + 7919L * (variant + 1));
            switch (preset) {
                case 0: mountains(c, w, h, r); break;
                case 1: aurora(c, w, h, r); break;
                case 2: synthwave(c, w, h); break;
                case 3: starry(c, w, h, r); break;
                case 4: lowPoly(c, w, h, r); break;
                case 5: bokeh(c, w, h, r); break;
                case 6: dunes(c, w, h, r); break;
                default: moon(c, w, h, r); break;
            }
        } else {
            Paint p = paint();
            p.setShader(new LinearGradient(0, 0, w, h, new int[]{bg[0], bg[1], bg[2]},
                    new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            if (style == 0) waves(c, w, h, wave, mul);
        }
        return b;
    }

    // ------------------------------------------------------------ помощники

    private static Paint paint() {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setDither(true);
        return p;
    }

    private static int clamp(int a) { return Math.max(0, Math.min(255, a)); }

    private static void fillV(Canvas c, int w, float top, float bottom, int[] colors) {
        Paint p = paint();
        p.setShader(new LinearGradient(0, top, 0, bottom, colors, null, Shader.TileMode.CLAMP));
        c.drawRect(0, top, w, bottom, p);
    }

    private static int lerp(int a, int b, float t) {
        int r = Math.round(Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = Math.round(Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = Math.round(Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }

    private static int shade(int col, float f) {
        return Color.rgb(clamp(Math.round(Color.red(col) * f)),
                clamp(Math.round(Color.green(col) * f)),
                clamp(Math.round(Color.blue(col) * f)));
    }

    private static void stars(Canvas c, int w, int h, Random r, int n, float maxY) {
        Paint p = paint();
        for (int i = 0; i < n; i++) {
            float x = r.nextFloat() * w;
            float y = r.nextFloat() * maxY;
            float rad = (0.5f + r.nextFloat() * 1.2f) * (h / 360f);
            int a = 90 + r.nextInt(165);
            p.setColor((a << 24) | 0x00FFFFFF);
            c.drawCircle(x, y, rad, p);
        }
    }

    // ---------------------------------------------------------------- волны

    private static void waves(Canvas c, int w, int h, int[] wave, float mul) {
        Paint fill = paint();
        Paint line = paint();
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(Math.max(1.5f, w * 0.0028f));
        int fa = clamp(Math.round(0x30 * mul));
        int la1 = clamp(Math.round(0xAA * mul));
        int la2 = clamp(Math.round(0x66 * mul));

        for (int i = 0; i < 3; i++) {
            float s = h * (0.60f + 0.075f * i);
            float e = h * (0.30f + 0.09f * i);
            float amp = h * 0.07f * (i % 2 == 0 ? 1 : -1);

            Path p = new Path();
            p.moveTo(0, s);
            p.cubicTo(w * 0.30f, s + amp, w * 0.58f, e - amp, w, e);
            Path f = new Path(p);
            f.lineTo(w, h);
            f.lineTo(0, h);
            f.close();

            int rgb = wave[i] & 0x00FFFFFF;
            fill.setShader(new LinearGradient(0, e, 0, h, (fa << 24) | rgb, rgb,
                    Shader.TileMode.CLAMP));
            c.drawPath(f, fill);
            line.setShader(new LinearGradient(0, 0, w, 0,
                    new int[]{rgb, (la1 << 24) | rgb, (la2 << 24) | rgb},
                    new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            c.drawPath(p, line);
        }
    }

    // ----------------------------------------------------------- 0. Горы

    private static void mountains(Canvas c, int w, int h, Random r) {
        fillV(c, w, 0, h, new int[]{0xFF1E1646, 0xFF7A3E7E, 0xFFF4A261});
        Paint p = paint();
        float sx = w * (0.62f + r.nextFloat() * 0.2f);
        float sy = h * 0.5f;
        float sr = h * 0.32f;
        p.setShader(new RadialGradient(sx, sy, sr,
                new int[]{0xFFFFF0B8, 0x88FFB36B, 0x00FFB36B},
                new float[]{0f, 0.3f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(sx, sy, sr, p);
        p.setShader(null);

        int[] cols = {0xFF5B3A7A, 0xFF3F2B63, 0xFF2A1F4F, 0xFF191236};
        for (int i = 0; i < 4; i++) {
            float base = h * (0.58f + 0.1f * i);
            float amp = h * (0.24f - 0.04f * i);
            Path path = new Path();
            path.moveTo(0, h);
            path.lineTo(0, base);
            float x = 0;
            while (x < w) {
                x += w * (0.04f + r.nextFloat() * 0.07f);
                path.lineTo(Math.min(x, w), base - r.nextFloat() * amp);
            }
            path.lineTo(w, h);
            path.close();
            p.setColor(cols[i]);
            c.drawPath(path, p);
        }
    }

    // ------------------------------------------------- 1. Северное сияние

    private static void aurora(Canvas c, int w, int h, Random r) {
        fillV(c, w, 0, h, new int[]{0xFF040916, 0xFF0A1A33, 0xFF0F2A44});
        stars(c, w, h, r, 140, h * 0.75f);
        int[] cs = {0xFF3DFFA8, 0xFF40C9FF, 0xFFB06CFF};
        Paint p = paint();
        for (int i = 0; i < 3; i++) {
            float by = h * (0.25f + 0.09f * i);
            float a1 = h * (0.10f + r.nextFloat() * 0.12f);
            float a2 = h * (0.08f + r.nextFloat() * 0.14f);
            Path pa = new Path();
            pa.moveTo(0, by);
            pa.cubicTo(w * 0.25f, by - a1, w * 0.6f, by + a2, w, by - h * 0.05f);
            pa.lineTo(w, by + h * 0.38f);
            pa.cubicTo(w * 0.6f, by + a2 + h * 0.4f, w * 0.25f, by - a1 + h * 0.3f, 0, by + h * 0.42f);
            pa.close();
            int rgb = cs[i] & 0x00FFFFFF;
            p.setShader(new LinearGradient(0, by - h * 0.1f, 0, by + h * 0.45f,
                    new int[]{(0xB0 << 24) | rgb, (0x40 << 24) | rgb, rgb},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            c.drawPath(pa, p);
        }
    }

    // ----------------------------------------------------- 2. Синтвейв

    private static void synthwave(Canvas c, int w, int h) {
        float hor = h * 0.62f;
        fillV(c, w, 0, hor, new int[]{0xFF140A3C, 0xFF7B1E7A, 0xFFFF6A88});

        float cx = w * 0.5f;
        float cy = hor - h * 0.02f;
        float rad = h * 0.24f;
        Paint p = paint();
        c.save();
        c.clipRect(0, 0, w, hor);
        p.setShader(new LinearGradient(0, cy - rad, 0, cy + rad, 0xFFFFE259, 0xFFFF2E93,
                Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, rad, p);
        p.setShader(null);
        p.setColor(0xFFE8587F);
        for (int k = 0; k < 5; k++) {
            float y = cy + rad * (0.2f * k);
            float th = rad * (0.03f + 0.025f * k);
            c.drawRect(cx - rad, y, cx + rad, y + th, p);
        }
        c.restore();

        fillV(c, w, hor, h, new int[]{0xFF2A0B4A, 0xFF0A0420});
        Paint line = paint();
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(Math.max(1f, h * 0.005f));
        line.setColor(0xCCFF3DCB);
        for (int i = 1; i <= 8; i++) {
            float t = i / 8f;
            float y = hor + (h - hor) * t * t;
            c.drawLine(0, y, w, y, line);
        }
        for (int i = -10; i <= 10; i++) {
            c.drawLine(cx, hor, cx + i * w * 0.14f, h, line);
        }
    }

    // ------------------------------------------------- 3. Звёздное небо

    private static void starry(Canvas c, int w, int h, Random r) {
        Paint p = paint();
        p.setShader(new RadialGradient(w * 0.5f, h * 0.5f, Math.max(w, h) * 0.75f,
                new int[]{0xFF14204A, 0xFF070B1F, 0xFF02030A},
                new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);

        c.save();
        c.rotate(-25f + r.nextFloat() * 10f, w / 2f, h / 2f);
        p.setShader(new LinearGradient(0, h * 0.3f, 0, h * 0.7f,
                new int[]{0x00B8C8FF, 0x44B8C8FF, 0x00B8C8FF},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(-w * 0.3f, h * 0.3f, w * 1.3f, h * 0.7f, p);
        c.restore();

        stars(c, w, h, r, 260, h);
        for (int i = 0; i < 7; i++) {
            float x = r.nextFloat() * w;
            float y = r.nextFloat() * h;
            float rad = h * (0.02f + r.nextFloat() * 0.03f) * 3f;
            p.setShader(new RadialGradient(x, y, rad,
                    new int[]{0xFFFFFFFF, 0x66BFD4FF, 0x00BFD4FF},
                    new float[]{0f, 0.2f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(x, y, rad, p);
        }
    }

    // ----------------------------------------------------- 4. Лоу-поли

    private static void lowPoly(Canvas c, int w, int h, Random r) {
        int cols = 14;
        int rows = 8;
        float[][] px = new float[rows + 1][cols + 1];
        float[][] py = new float[rows + 1][cols + 1];
        for (int j = 0; j <= rows; j++) {
            for (int i = 0; i <= cols; i++) {
                float x = i * (float) w / cols;
                float y = j * (float) h / rows;
                if (i > 0 && i < cols) x += (r.nextFloat() - 0.5f) * w / cols * 0.7f;
                if (j > 0 && j < rows) y += (r.nextFloat() - 0.5f) * h / rows * 0.7f;
                px[j][i] = x;
                py[j][i] = y;
            }
        }
        Paint p = paint();
        Paint st = paint();
        st.setStyle(Paint.Style.STROKE);
        st.setStrokeWidth(1f);
        for (int j = 0; j < rows; j++) {
            for (int i = 0; i < cols; i++) {
                float ax = px[j][i], ay = py[j][i];
                float bx = px[j][i + 1], by = py[j][i + 1];
                float cx = px[j + 1][i + 1], cy = py[j + 1][i + 1];
                float dx = px[j + 1][i], dy = py[j + 1][i];
                if (r.nextBoolean()) {
                    tri(c, p, st, r, w, h, ax, ay, bx, by, cx, cy);
                    tri(c, p, st, r, w, h, ax, ay, cx, cy, dx, dy);
                } else {
                    tri(c, p, st, r, w, h, ax, ay, bx, by, dx, dy);
                    tri(c, p, st, r, w, h, bx, by, cx, cy, dx, dy);
                }
            }
        }
    }

    private static void tri(Canvas c, Paint p, Paint st, Random r, int w, int h,
                            float x1, float y1, float x2, float y2, float x3, float y3) {
        float t = (((x1 + x2 + x3) / 3f) / w + ((y1 + y2 + y3) / 3f) / h) / 2f;
        int c1 = 0xFF1B2A6B;
        int c2 = 0xFF6B2D8F;
        int c3 = 0xFF0E7C86;
        int base = t < 0.5f ? lerp(c1, c2, t * 2f) : lerp(c2, c3, (t - 0.5f) * 2f);
        int col = shade(base, 0.8f + r.nextFloat() * 0.4f);
        Path path = new Path();
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        path.lineTo(x3, y3);
        path.close();
        p.setColor(col);
        st.setColor(col);
        c.drawPath(path, p);
        c.drawPath(path, st);
    }

    // ---------------------------------------------------------- 5. Боке

    private static void bokeh(Canvas c, int w, int h, Random r) {
        fillV(c, w, 0, h, new int[]{0xFF0B1030, 0xFF2A1250});
        int[] pal = {0xFF4FD1FF, 0xFFFF6AD5, 0xFF8E6BFF, 0xFFFFC857};
        Paint p = paint();
        for (int i = 0; i < 24; i++) {
            float rad = h * (0.05f + r.nextFloat() * 0.15f);
            float x = r.nextFloat() * w;
            float y = r.nextFloat() * h;
            int rgb = pal[r.nextInt(pal.length)] & 0x00FFFFFF;
            p.setShader(new RadialGradient(x, y, rad,
                    new int[]{(0x66 << 24) | rgb, (0x33 << 24) | rgb, rgb},
                    new float[]{0f, 0.75f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(x, y, rad, p);
        }
    }

    // ---------------------------------------------------------- 6. Дюны

    private static void dunes(Canvas c, int w, int h, Random r) {
        fillV(c, w, 0, h, new int[]{0xFF3D2C5A, 0xFFE08E6B, 0xFFF7C28A});
        Paint p = paint();
        float gx = w * 0.3f;
        float gy = h * 0.45f;
        float gr = h * 0.3f;
        p.setShader(new RadialGradient(gx, gy, gr,
                new int[]{0xAAFFF0C8, 0x00FFF0C8}, null, Shader.TileMode.CLAMP));
        c.drawCircle(gx, gy, gr, p);
        p.setShader(null);

        int[] cols = {0xFFC9794A, 0xFFA85C3B, 0xFF7E3F2E, 0xFF4A2424};
        for (int i = 0; i < 4; i++) {
            float base = h * (0.52f + 0.12f * i);
            float amp = h * (0.07f + 0.02f * i);
            float freq = (1.5f + r.nextFloat() * 1.5f) * (float) Math.PI * 2f / w;
            float ph = r.nextFloat() * 6.28f;
            Path path = new Path();
            path.moveTo(0, h);
            int steps = 48;
            for (int s = 0; s <= steps; s++) {
                float x = w * s / (float) steps;
                float y = base - amp * (float) Math.sin(x * freq + ph)
                        - amp * 0.5f * (float) Math.sin(x * freq * 2.3f + ph * 1.7f);
                path.lineTo(x, y);
            }
            path.lineTo(w, h);
            path.close();
            p.setColor(cols[i]);
            c.drawPath(path, p);
        }
    }

    // ----------------------------------------------------- 7. Лунная ночь

    private static void moon(Canvas c, int w, int h, Random r) {
        fillV(c, w, 0, h, new int[]{0xFF060A1A, 0xFF0F1B3D, 0xFF1D2F5C});
        stars(c, w, h, r, 90, h * 0.7f);

        float mx = w * (0.65f + (r.nextFloat() - 0.5f) * 0.2f);
        float my = h * 0.3f;
        float mr = h * 0.09f;
        Paint p = paint();
        float glow = h * 0.45f;
        p.setShader(new RadialGradient(mx, my, glow,
                new int[]{0x55CFE3FF, 0x00CFE3FF}, null, Shader.TileMode.CLAMP));
        c.drawCircle(mx, my, glow, p);
        p.setShader(null);
        p.setColor(0xFFEAF2FF);
        c.drawCircle(mx, my, mr, p);

        p.setColor(0x22FFFFFF);
        for (int i = 0; i < 4; i++) {
            float x = r.nextFloat() * w * 0.8f;
            float y = h * (0.15f + r.nextFloat() * 0.35f);
            c.drawOval(new RectF(x, y, x + w * (0.2f + r.nextFloat() * 0.2f), y + h * 0.04f), p);
        }

        int[] cols = {0xFF0B1330, 0xFF060A1A};
        for (int i = 0; i < 2; i++) {
            float base = h * (0.78f + 0.09f * i);
            float amp = h * 0.05f;
            float freq = (1.2f + r.nextFloat() * 1.5f) * (float) Math.PI * 2f / w;
            float ph = r.nextFloat() * 6.28f;
            Path path = new Path();
            path.moveTo(0, h);
            int steps = 40;
            for (int s = 0; s <= steps; s++) {
                float x = w * s / (float) steps;
                path.lineTo(x, base - amp * (float) Math.sin(x * freq + ph));
            }
            path.lineTo(w, h);
            path.close();
            p.setColor(cols[i]);
            c.drawPath(path, p);
        }
    }
}
